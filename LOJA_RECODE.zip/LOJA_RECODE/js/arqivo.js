document.getElementById("coordenadas").onmousemove = function(event) {
    myFunction(event)
};
/*minha funcao das coordenadas X,Y das imagens */
function myFunction(e) {
var x = e.clientX;//variavel X pega valor X coordenada
var y = e.clientY;//variavel Y pega valor Y coordenada
var coor = "Coordinates: (" + x + "," + y + ")";
/*criaçao do demos sendo foi criado um para cada image ja que os ID sao apenas para cada elemento usar nas imagens com produtos esgotados*/
//Acessa e fazer a modificaçao por ID
document.getElementById("demo1").innerHTML = coor;/*Retorna a referência do elemento através do seu ID demo1.*/
document.getElementById("demo2").innerHTML = coor;/*Retorna a referência do elemento através do seu ID demo2.*/
document.getElementById("demo3").innerHTML = coor;/*Retorna a referência do elemento através do seu ID demo3.*/
document.getElementById("demo4").innerHTML = coor;/*Retorna a referência do elemento através do seu ID demo4.*/
}
//usando clicks nos Menu superior
//criar uma funcao click o um bloco de codigos para quuano for clicado mostra informaçoes de descontos telefones
function click_menu_telefone() {
alert("Todos os Telefones Estao na promoçao de 25% de descontos");
}

//criar uma funcao click o um bloco de codigos para quuano for clicado mostra informaçoes de descontos eletrodomesticos
function click_menu_eletrodomesticos() {
alert("Todos os eletros Estao na promoçao de 35% de descontos");
}

//criar uma funcao click o um bloco de codigos para quuano for clicado mostra informaçoes de descontos moveis
function click_menu_moveis() {
alert("Todos os moveis Estao na promoçao de 45% de descontos");
}

//criar uma funcao click o um bloco de codigos para quuano for clicado mostra informaçoes de descontos tecnologia
function click_menu_tecnologia() {
alert("Todos as tecnologias Estao na promoçao de 55% de descontos");
} 

//criar uma funcao click o um bloco de codigos para quuano for clicado mostra informaçoes de descontos tvs
function click_menu_tvs() {
alert("Todos as tvs Estao na promoçao de 65% de descontos");
}