
<?php

    $nome = ($_POST['nome']);
    $email = ($_POST['email']);
    $telefone = ($_POST['telefone']);
    $senha = ($_POST['senha']);

    $conn = mysqli_connect('localhost:3307',
                          'root',
                          'usbw',
                          'trabalho01');
 if (!$conn){
    die("A conexao ao BD falhou:" .mysqli_connect_erro());
    }

    $sql = "insert into cadastro (nome,email,telefone,senha) 
    values($nome,$email,$telefone,$senha)";
    mysqli_close($conn);
    

?>
