<html>

<head>
    <title></title>

</head>

<body bgcolor="green">
    <center style="color: white;"><h1> consultar e exibir os produtos registrados do banco de dados</h1></center>
</body>
</html>



<?php
    //localhost
    $servename ="localhost";
    //username
    $username = "root";
    //password
    $password = "usbw";
    //database
    $database = "loja";

    //criar conexao
    $conn = mysqli_connect($servename,
                           $username,
                           $password,
                           $database);

    //verificar conexao
    if (!$conn){
        die("A conexao ao BD falhou:" .mysqli_connect_erro());
    }
 
    $sql = "select categoria,descricao,preco,precofinal,imagem from produto";
    $result =$conn->query($sql);

    while ($row=$result->fetch_assoc()) {
        //print_r($row); trazer um array
        echo $row["categoria"].$row["descricao"].$row["preco"].$row["precofinal"].$row["imagem"];
        echo "<hr>";
    }

    mysqli_close($conn);
    


?>